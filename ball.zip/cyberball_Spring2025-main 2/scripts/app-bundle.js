define('app',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.App = void 0;
    class App {
        configureRouter(config, router) {
            this.router = router;
            config.title = 'Cyberball';
            config.map([
                { route: ['', 'LandingPage'], name: 'LandingPage', moduleId: 'pages/LandingPage/LandingPage' },
                { route: 'home', name: 'home', moduleId: 'pages/Home/home' },
                { route: 'game', name: 'game', moduleId: 'pages/Game/game' },
                { route: 'PresetPage', name: 'PresetPage', moduleId: 'pages/PresetPage/PresetPage' },
                { route: 'message-test', name: 'message-test', moduleId: 'pages/message-test' }
            ]);
        }
    }
    exports.App = App;
});
;
define('text!app.html',[],function(){return "<template>\n    <router-view></router-view>\n</template>\n";});;
define('environment',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = {
        debug: true,
        testing: true
    };
});
;
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('game/CpuTargeting',["require", "exports", "./CyberballGameModel"], function (require, exports, CyberballGameModel_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.convertTextToSchedule = void 0;
    CyberballGameModel_1 = __importDefault(CyberballGameModel_1);
    function addCpuTargeting(controller, settings) {
        if (settings.useSchedule) {
            addCpuTargetingSchedule(controller, settings);
        }
        else {
            addCpuTargetingPreference(controller, settings);
        }
    }
    exports.default = addCpuTargeting;
    function addCpuTargetingSchedule(controller, settings) {
        let schedule = convertTextToSchedule(settings.scheduleText);
        console.log(schedule);
        controller.setCpuTargeting(id => {
            let scheduleQueue = schedule.get(id);
            let nextTarget = scheduleQueue.shift();
            let isValidTarget = (target) => {
                let differentFromSelf = target !== id;
                let playerStillInGame = controller.model.remainingCpuPlayerIds.has(target) || target === CyberballGameModel_1.default.humanPlayerId;
                return differentFromSelf && playerStillInGame;
            };
            while (!isValidTarget(nextTarget)) {
                if (scheduleQueue.length === 0) {
                    controller.endGame("throw-count-met");
                    break;
                }
                nextTarget = scheduleQueue.shift();
            }
            return nextTarget;
        });
    }
    function convertTextToSchedule(str) {
        const lines = str.split('\n');
        const schedule = new Map();
        for (const line of lines) {
            const [key, ...values] = line.split(',').map(Number);
            schedule.set(key - 2, values);
        }
        schedule.forEach((value, key) => {
            schedule.set(key, addRandomizationToScheduleNumbers(value).map(num => num - 2));
        });
        return schedule;
    }
    exports.convertTextToSchedule = convertTextToSchedule;
    function addRandomizationToScheduleNumbers(input) {
        let newSchedule = [];
        input.forEach(number => {
            if (number > 9) {
                let digits = number.toString().split('');
                for (let i = digits.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [digits[i], digits[j]] = [digits[j], digits[i]];
                }
                digits.forEach(digit => newSchedule.push(parseInt(digit)));
            }
            else {
                newSchedule.push(number);
            }
        });
        return newSchedule;
    }
    function addCpuTargetingPreference(controller, settings) {
        settings.computerPlayers.forEach(cpuSetting => {
            let sum = cpuSetting.targetPreference.reduce((sum, value) => sum + value);
            if (sum === 0) {
                console.warn("No targets for CPU?");
                cpuSetting.throwDelay = 1000000000;
                return;
            }
            cpuSetting.targetPreference = cpuSetting.targetPreference.map(el => el / sum * 100);
        });
        controller.setCpuTargeting(thrower => {
            let targetPreference = settings.computerPlayers[thrower].targetPreference;
            let probablyityDensityFunction = targetPreference.map(el => el / 100);
            let cumultiveDistributionFunction = probablyityDensityFunction.map((sum => value => sum += value)(0));
            let rand = Math.random();
            let index = cumultiveDistributionFunction.findIndex(el => rand <= el);
            return index <= thrower ? index - 1 : index;
        });
        controller.CPULeaveCallbacks.addCallback("Target Preference", (id) => {
            settings.computerPlayers.forEach((cpuSetting, index) => {
                cpuSetting.targetPreference[id > index ? id : id + 1] = 0;
                let sum = cpuSetting.targetPreference.reduce((sum, value) => sum + value);
                if (sum === 0) {
                    console.warn(`All targets for CPU ${id} have left!`);
                    cpuSetting.throwDelay = 1000000000;
                    return;
                }
                cpuSetting.targetPreference = cpuSetting.targetPreference.map(el => el / sum * 100);
            });
        });
    }
});
;
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('game/CyberballGameController',["require", "exports", "./callback-list", "./CyberballGameModel"], function (require, exports, callback_list_1, CyberballGameModel_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    callback_list_1 = __importDefault(callback_list_1);
    CyberballGameModel_1 = __importDefault(CyberballGameModel_1);
    class CyberballGameController {
        constructor(playerStartingWithBall, numberOfCpuPlayers) {
            this.nextPlannedTarget = null;
            this.CPULeaveCallbacks = new callback_list_1.default();
            this.throwBallCallbacks = new callback_list_1.default();
            this.catchBallCallbacks = new callback_list_1.default();
            this.humanPlayerMayLeaveCallbacks = new callback_list_1.default();
            this.gameEndCallbacks = new callback_list_1.default();
            this.getNextCpuTarget = s => s;
            this.model = new CyberballGameModel_1.default();
            this.model.playerHoldingBallId = playerStartingWithBall;
            for (let i = 0; i < numberOfCpuPlayers; i++) {
                this.model.remainingCpuPlayerIds.add(i);
            }
        }
        setCpuTargeting(getNextCpuTarget) {
            this.getNextCpuTarget = getNextCpuTarget;
        }
        removeCPUfromGame(id, reason) {
            if (this.model.gameHasEnded) {
                return;
            }
            let isHolding = this.model.playerHoldingBallId === id;
            let isCatching = this.model.throwTargetId === id;
            let alreadyLeft = !this.model.remainingCpuPlayerIds.has(id);
            if (isHolding || isCatching || alreadyLeft) {
                return;
            }
            this.model.remainingCpuPlayerIds.delete(id);
            this.CPULeaveCallbacks.runCallbacks(id, reason);
        }
        throwBall(target) {
            if (this.model.gameHasEnded) {
                return;
            }
            if (this.model.playerHoldingBallId === null) {
                console.warn("Attempting to throw ball when nobody is holding it?");
                return;
            }
            if (this.model.playerHoldingBallId === target) {
                console.warn("Player throwing ball to themselves?");
                return;
            }
            let playerHoldingBall = this.model.playerHoldingBallId;
            this.model.playerHoldingBallId = null;
            this.model.throwTargetId = target;
            this.throwBallCallbacks.runCallbacks(playerHoldingBall, target);
        }
        cpuThrowBall() {
            if (this.model.gameHasEnded) {
                return;
            }
            if (this.model.playerHoldingBallId === null || CyberballGameModel_1.default.humanPlayerId === this.model.playerHoldingBallId) {
                console.warn("Attempting CPU throw ball when CPU not holding it?");
            }
            if (this.nextPlannedTarget !== null) {
                this.throwBall(this.nextPlannedTarget);
                this.nextPlannedTarget = null;
            }
            else {
                this.throwBall(this.getNextCpuTarget(this.model.playerHoldingBallId));
            }
        }
        completeCatch() {
            if (this.model.gameHasEnded) {
                return;
            }
            if (this.model.throwTargetId === null) {
                console.warn("Attempting to catch ball without target?");
                return;
            }
            this.model.playerHoldingBallId = this.model.throwTargetId;
            this.model.throwTargetId = null;
            this.model.throwCount += 1;
            this.catchBallCallbacks.runCallbacks(this.model.playerHoldingBallId);
        }
        allowPlayerToLeave(reason) {
            if (this.model.humanPlayerMayLeave || this.model.gameHasEnded) {
                return;
            }
            this.model.humanPlayerMayLeave = true;
            this.humanPlayerMayLeaveCallbacks.runCallbacks(reason);
        }
        endGame(reason) {
            if (this.model.gameHasEnded) {
                return;
            }
            this.model.gameHasEnded = true;
            this.gameEndCallbacks.runCallbacks(reason);
        }
        reportTimeSinceStart() {
            return Date.now() - this.model.startTime;
        }
        getNextTarget(thrower) {
            if (!this.model.remainingCpuPlayerIds.has(thrower) && thrower !== CyberballGameModel_1.default.humanPlayerId) {
                return null;
            }
            if (this.nextPlannedTarget !== null) {
                return this.nextPlannedTarget;
            }
            this.nextPlannedTarget = this.getNextCpuTarget(thrower);
            return this.nextPlannedTarget;
        }
    }
    exports.default = CyberballGameController;
});
;
define('game/CyberballGameModel',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class CyberballGameModel {
        constructor() {
            this.playerHoldingBallId = null;
            this.throwTargetId = null;
            this.remainingCpuPlayerIds = new Set();
            this.humanPlayerMayLeave = false;
            this.gameHasEnded = false;
            this.startTime = Date.now();
            this.throwCount = 0;
        }
    }
    exports.default = CyberballGameModel;
    CyberballGameModel.humanPlayerId = -1;
});
;
define('game/GameLog',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.addGameLogging = void 0;
    function addGameLogging(controller, settings) {
        let numPlayers = settings.computerPlayers.length + 1;
        let gameLog = [];
        let timeAtCatch = 0;
        let humanLeaveReason = "";
        let humanMayLeaveTime = 0;
        controller.catchBallCallbacks.addCallback("grab time at catch", () => {
            timeAtCatch = controller.reportTimeSinceStart();
        });
        controller.throwBallCallbacks.addCallback("log throw", (throwerID, recieverID) => {
            gameLog.push({ "type": "throw", "thrower": throwerID + 2, "reciever": recieverID + 2, "wait": controller.reportTimeSinceStart() - timeAtCatch });
        });
        controller.CPULeaveCallbacks.addCallback("log leave", (cpuID, reason) => {
            gameLog.push({ "type": "CPU leave", "leaver": cpuID + 2, "reason": reason, "time": controller.reportTimeSinceStart() });
        });
        controller.humanPlayerMayLeaveCallbacks.addCallback("log player may leave", reason => {
            gameLog.push({ "type": "player may leave", "reason": reason, "time": controller.reportTimeSinceStart() });
            humanLeaveReason = reason;
            humanMayLeaveTime = controller.reportTimeSinceStart();
        });
        controller.gameEndCallbacks.addCallback("log and post game end", reason => {
            gameLog.push({ "type": "game end", "reason": reason, "time": controller.reportTimeSinceStart() });
            processAndReportGameLog(controller.model.throwCount, controller.reportTimeSinceStart(), numPlayers, gameLog, humanLeaveReason, humanMayLeaveTime);
        });
    }
    exports.addGameLogging = addGameLogging;
    function processAndReportGameLog(throwCount, totalTime, numPlayers, gameLog, humanLeaveReason, humanMayLeaveTime) {
        let throwStats = Array(numPlayers).fill([]).map(() => Array(numPlayers).fill(0));
        for (let entry of gameLog) {
            if (entry.type === "throw") {
                throwStats[entry.thrower - 1][entry.reciever - 1]++;
            }
        }
        let msg = {
            "game_log": gameLog,
            "throws_formatted": throwStats,
            "player_throws_list": buildListOfPlayerThrows(throwStats, numPlayers),
            "total_throws": throwCount,
            "player_may_leave_reason": humanLeaveReason,
            "player_may_leave_time": humanMayLeaveTime,
            "total_time": totalTime
        };
        console.log(msg);
        window.parent.postMessage(msg, '*');
    }
    function buildListOfPlayerThrows(throwStats, numPlayers) {
        let msg = {};
        let loopCount = Math.min(numPlayers, 4);
        for (let i = 0; i < loopCount; i++) {
            for (let j = 0; j < loopCount; j++) {
                if (i != j)
                    msg['Player_' + (i + 1) + '_to_Player_' + (j + 1)] = throwStats[i][j];
            }
        }
        return msg;
    }
});
;
define('game/GameOverTriggers',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.addAllCpusLeftGameOverTrigger = exports.addTimeLimitGameOverTrigger = exports.addThrowCountGameOverTrigger = void 0;
    function addGameOverTriggers(controller, settings) {
        if (settings.selectedGameOverCondition === "throwCount") {
            if (settings.useSchedule && !settings.scheduleHonorsThrowCount) {
                return;
            }
            addThrowCountGameOverTrigger(controller, settings.throwCount);
        }
        else if (settings.selectedGameOverCondition === "timeLimit") {
            addTimeLimitGameOverTrigger(controller, settings.timeLimit);
        }
        else if (settings.selectedGameOverCondition === "allCPUsLeft") {
            addAllCpusLeftGameOverTrigger(controller);
        }
    }
    exports.default = addGameOverTriggers;
    function addThrowCountGameOverTrigger(controller, throwCount) {
        controller.catchBallCallbacks.addCallback("Game Over", () => {
            if (controller.model.throwCount >= throwCount) {
                controller.endGame("throw-count-met");
            }
        });
    }
    exports.addThrowCountGameOverTrigger = addThrowCountGameOverTrigger;
    function addTimeLimitGameOverTrigger(controller, timeLimit) {
        if (timeLimit <= 0) {
            return;
        }
        setTimeout(() => {
            controller.endGame("global-time-limit");
        }, timeLimit);
    }
    exports.addTimeLimitGameOverTrigger = addTimeLimitGameOverTrigger;
    function addAllCpusLeftGameOverTrigger(controller) {
        controller.CPULeaveCallbacks.addCallback("Game Over", () => {
            if (controller.model.remainingCpuPlayerIds.size === 0) {
                controller.endGame("All CPUs left");
            }
        });
    }
    exports.addAllCpusLeftGameOverTrigger = addAllCpusLeftGameOverTrigger;
});
;
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('game/LeaveTriggers',["require", "exports", "models/player-settings-model", "./CyberballGameModel"], function (require, exports, player_settings_model_1, CyberballGameModel_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.addTimeIgnoredLeaveTrigger = exports.addOtherLeaverLeaveTrigger = exports.addIgnoredLeaveTrigger = exports.addTimeLeaveTrigger = exports.addTurnLeaveTrigger = exports.addLeaveTriggers = exports.addPlayerMayLeaveTriggers = exports.addAllCpuLeaveTriggers = void 0;
    CyberballGameModel_1 = __importDefault(CyberballGameModel_1);
    function addAllLeaveTriggers(controller, settings) {
        addAllCpuLeaveTriggers(controller, settings);
        addPlayerMayLeaveTriggers(controller, settings);
    }
    exports.default = addAllLeaveTriggers;
    function addAllCpuLeaveTriggers(controller, settings) {
        settings.computerPlayers.forEach((cpuSettings, index) => {
            const callback = (reason) => controller.removeCPUfromGame(index, reason);
            addLeaveTriggers(controller, index, callback, cpuSettings, settings.computerPlayers.length);
        });
    }
    exports.addAllCpuLeaveTriggers = addAllCpuLeaveTriggers;
    function addPlayerMayLeaveTriggers(controller, settings) {
        const callback = (reason) => controller.allowPlayerToLeave(reason);
        addLeaveTriggers(controller, CyberballGameModel_1.default.humanPlayerId, callback, settings.player, settings.computerPlayers.length);
    }
    exports.addPlayerMayLeaveTriggers = addPlayerMayLeaveTriggers;
    function shouldDisableLeaveTrigger(settings, leavePercentageAttr) {
        const leavePercentage = leavePercentageAttr in settings ? settings[leavePercentageAttr] : 100;
        return leavePercentage <= Math.random() * 100;
    }
    function floatingRandom(mean, variance) {
        return mean + (Math.random() * 2 * variance - variance);
    }
    function integralRandom(mean, variance) {
        return Math.floor(mean + (Math.random() * (2 * variance + 1) - variance));
    }
    function addLeaveTriggers(controller, playerId, leaveCallback, settings, totalNumberOfCpus) {
        if (settings.leaveTrigger & player_settings_model_1.LeaveTrigger.Turn) {
            if (shouldDisableLeaveTrigger(settings, 'leaveTurnChance'))
                return;
            let leaveTurn = integralRandom(settings.leaveTurn, settings.leaveTurnVariance);
            addTurnLeaveTrigger(controller, playerId, leaveCallback, leaveTurn);
        }
        if (settings.leaveTrigger & player_settings_model_1.LeaveTrigger.Time) {
            if (shouldDisableLeaveTrigger(settings, 'leaveTimeChance'))
                return;
            let leaveTimeMilliseconds = floatingRandom(settings.leaveTime, settings.leaveTimeVariance);
            addTimeLeaveTrigger(controller, playerId, leaveCallback, leaveTimeMilliseconds);
        }
        if (settings.leaveTrigger & player_settings_model_1.LeaveTrigger.Ignored) {
            if (shouldDisableLeaveTrigger(settings, 'leaveIgnoredChance'))
                return;
            let leaveThrows = integralRandom(settings.leaveIgnored, settings.leaveIgnoredVariance);
            addIgnoredLeaveTrigger(controller, playerId, leaveCallback, leaveThrows);
        }
        if (settings.leaveTrigger & player_settings_model_1.LeaveTrigger.OtherLeaver) {
            if (shouldDisableLeaveTrigger(settings, 'leaveOtherLeaverChance'))
                return;
            addOtherLeaverLeaveTrigger(controller, playerId, leaveCallback, settings.leaveOtherLeaver, totalNumberOfCpus);
        }
        if (settings.leaveTrigger & player_settings_model_1.LeaveTrigger.TimeIgnored) {
            if (shouldDisableLeaveTrigger(settings, 'leaveTimeIgnoredChance'))
                return;
            let leaveTimeMilliseconds = floatingRandom(settings.leaveTimeIgnored, settings.leaveTimeIgnored);
            addTimeIgnoredLeaveTrigger(controller, playerId, leaveCallback, leaveTimeMilliseconds);
        }
    }
    exports.addLeaveTriggers = addLeaveTriggers;
    function addTurnLeaveTrigger(controller, playerId, leaveCallback, leaveTurn) {
        controller.catchBallCallbacks.addCallback(`Player ${playerId} LeaveTrigger.Turn`, () => {
            if (controller.model.throwCount >= leaveTurn) {
                leaveCallback("throws elapsed");
            }
        });
    }
    exports.addTurnLeaveTrigger = addTurnLeaveTrigger;
    function addTimeLeaveTrigger(controller, playerId, leaveCallback, leaveTime) {
        if (leaveTime <= 0) {
            return;
        }
        setTimeout(() => {
            leaveCallback('time elapsed');
            controller.throwBallCallbacks.addCallback(`Player ${playerId} LeaveTrigger.Time`, () => {
                leaveCallback('time elapsed');
            });
        }, leaveTime);
    }
    exports.addTimeLeaveTrigger = addTimeLeaveTrigger;
    function addIgnoredLeaveTrigger(controller, playerId, leaveCallback, leaveThrows) {
        let throwsIgnored = controller.model.playerHoldingBallId === playerId ? 0 : 1;
        controller.catchBallCallbacks.addCallback(`Player ${playerId} LeaveTrigger.Ignored`, id => {
            if (id == playerId) {
                throwsIgnored = 0;
            }
            else {
                throwsIgnored += 1;
            }
            if (throwsIgnored > leaveThrows) {
                leaveCallback('throws ignored');
            }
        });
    }
    exports.addIgnoredLeaveTrigger = addIgnoredLeaveTrigger;
    function addOtherLeaverLeaveTrigger(controller, playerId, leaveCallback, leaveOtherLeaver, totalNumberOfCpus) {
        controller.CPULeaveCallbacks.addCallback(`Player ${playerId} LeaveTrigger.OtherLeaver`, () => {
            let enoughPlayersLeft = totalNumberOfCpus - controller.model.remainingCpuPlayerIds.size >= leaveOtherLeaver;
            if (enoughPlayersLeft) {
                leaveCallback('other leavers');
                controller.throwBallCallbacks.addCallback(`Player ${playerId} LeaveTrigger.OtherLeaver`, () => {
                    leaveCallback('other leavers');
                });
            }
        });
    }
    exports.addOtherLeaverLeaveTrigger = addOtherLeaverLeaveTrigger;
    function addTimeIgnoredLeaveTrigger(controller, playerId, leaveCallback, leaveTime) {
        let interactionId = 0;
        let callback = (originalInteractionId) => {
            return () => {
                let isHolding = controller.model.playerHoldingBallId === playerId;
                let isCatching = controller.model.throwTargetId === playerId;
                if (isHolding || isCatching) {
                    return;
                }
                if (originalInteractionId === interactionId) {
                    leaveCallback('time ignored');
                }
            };
        };
        setTimeout(callback(interactionId), leaveTime);
        controller.throwBallCallbacks.addCallback(`Player ${playerId} LeaveTrigger.TimeIgnored`, (thrower, reciever) => {
            if (thrower === playerId) {
                interactionId++;
                setTimeout(callback(interactionId), leaveTime);
            }
            if (reciever === playerId) {
                interactionId++;
            }
        });
    }
    exports.addTimeIgnoredLeaveTrigger = addTimeIgnoredLeaveTrigger;
});
;
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define('game/callback-list',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function defaultExceptionHandler(e, callbackIdentifier) {
        console.error(`default CallbackList exception handler, callbackIdentifier: ${callbackIdentifier}`);
        console.error(e);
    }
    class CallbackList {
        constructor(exceptionHandler = defaultExceptionHandler) {
            this.callbacks = new Map();
            this.exceptionHandler = exceptionHandler;
        }
        addCallback(identifier, callback) {
            if (this.callbacks.has(identifier)) {
                return false;
            }
            this.callbacks.set(identifier, callback);
            return true;
        }
        removeCallback(identifier) {
            return this.callbacks.delete(identifier);
        }
        runCallbacks(...args) {
            return __awaiter(this, void 0, void 0, function* () {
                const promises = [];
                for (const [identifier, callback] of this.callbacks) {
                    try {
                        const result = callback(...args);
                        if (result) {
                            promises.push(result.catch((e) => this.exceptionHandler(e, identifier)));
                        }
                    }
                    catch (e) {
                        this.exceptionHandler(e, identifier);
                    }
                }
                yield Promise.all(promises);
            });
        }
        runCallbacksBlocking(...args) {
            return __awaiter(this, void 0, void 0, function* () {
                for (const [identifier, callback] of this.callbacks) {
                    try {
                        yield callback(...args);
                    }
                    catch (e) {
                        this.exceptionHandler(e, identifier);
                    }
                }
            });
        }
        runCallbacksDeferred(delayMs, ...args) {
            setTimeout(() => {
                this.runCallbacks(...args);
            }, delayMs);
        }
    }
    exports.default = CallbackList;
});
;
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('main',["require", "exports", "./environment"], function (require, exports, environment_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.configure = void 0;
    environment_1 = __importDefault(environment_1);
    function configure(aurelia) {
        aurelia.use
            .standardConfiguration()
            .feature('resources');
        aurelia.use.developmentLogging(environment_1.default.debug ? 'debug' : 'warn');
        if (environment_1.default.testing) {
            aurelia.use.plugin('aurelia-testing');
        }
        aurelia.start().then(() => aurelia.setRoot());
    }
    exports.configure = configure;
});
;
define('models/cpu-settings-model',["require", "exports", "./player-settings-model"], function (require, exports, player_settings_model_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CpuSettingsModel = void 0;
    class CpuSettingsModel extends player_settings_model_1.PlayerSettingsModel {
        constructor(init) {
            super();
            this.targetPreference = [50, 50];
            this.throwDelay = 500;
            this.throwDelayVariance = 200;
            this.catchDelay = 500;
            this.catchDelayVariance = 200;
            this.leaveTurnChance = 100;
            this.leaveTimeChance = 100;
            this.leaveIgnoredChance = 100;
            this.leaveTimeIgnoredChance = 100;
            this.leaveOtherLeaverChance = 50;
            if (init)
                Object.assign(this, init);
        }
    }
    exports.CpuSettingsModel = CpuSettingsModel;
});
;
define('models/player-settings-model',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PlayerSettingsModel = exports.LeaveTrigger = void 0;
    var LeaveTrigger;
    (function (LeaveTrigger) {
        LeaveTrigger[LeaveTrigger["None"] = 0] = "None";
        LeaveTrigger[LeaveTrigger["Turn"] = 1] = "Turn";
        LeaveTrigger[LeaveTrigger["Time"] = 2] = "Time";
        LeaveTrigger[LeaveTrigger["Ignored"] = 4] = "Ignored";
        LeaveTrigger[LeaveTrigger["OtherLeaver"] = 8] = "OtherLeaver";
        LeaveTrigger[LeaveTrigger["TimeIgnored"] = 16] = "TimeIgnored";
    })(LeaveTrigger = exports.LeaveTrigger || (exports.LeaveTrigger = {}));
    class PlayerSettingsModel {
        constructor(init) {
            this.tint = '#ffffff';
            this.leaveTrigger = LeaveTrigger.None;
            this.leaveTurn = 10;
            this.leaveTurnVariance = 2;
            this.leaveTime = 120000;
            this.leaveTimeVariance = 30000;
            this.leaveIgnored = 10;
            this.leaveIgnoredVariance = 2;
            this.leaveTimeIgnored = 45000;
            this.leaveTimeIgnoredVariance = 15000;
            this.leaveOtherLeaver = 2;
            if (init)
                Object.assign(this, init);
        }
    }
    exports.PlayerSettingsModel = PlayerSettingsModel;
});
;
define('models/settings-model',["require", "exports", "./player-settings-model", "./cpu-settings-model"], function (require, exports, player_settings_model_1, cpu_settings_model_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.defaultSettings = exports.SettingsModel = void 0;
    class SettingsModel {
        get hasPortraits() {
            return this.player.portraitBuff || this.computerPlayers.some(cpu => cpu.portraitBuff);
        }
        constructor(init) {
            this.player = new player_settings_model_1.PlayerSettingsModel();
            this.throwCount = 10;
            this.timeLimit = 0;
            this.displayTimeLimit = false;
            this.timeLimitText = 'Time Limit:';
            this.ballSpeed = 500;
            this.useSchedule = false;
            this.scheduleHonorsThrowCount = false;
            this.selectedGameOverCondition = 'throwCount';
            this.gameOverConditions = [
                { id: 'throwCount', label: 'Throw Count' },
                { id: 'timeLimit', label: 'Time Limit' },
                { id: 'allCPUsLeft', label: 'All CPUs Left' }
            ];
            this.baseUrl = './assets';
            this.ballSprite = 'ball.png';
            this.ballTint = '#ffffff';
            this.portraitHeight = 75;
            this.portraitPadding = 10;
            this.chatEnabled = false;
            this.gameOverText = "Game Over";
            this.gameOverOpacity = 0.5;
            Object.assign(this, init);
        }
    }
    exports.SettingsModel = SettingsModel;
    function defaultSettings() {
        return new SettingsModel({
            player: new player_settings_model_1.PlayerSettingsModel({
                name: 'Player 1'
            }),
            computerPlayers: [
                new cpu_settings_model_1.CpuSettingsModel({
                    name: 'Player 2'
                }),
                new cpu_settings_model_1.CpuSettingsModel({
                    name: 'Player 3'
                })
            ]
        });
    }
    exports.defaultSettings = defaultSettings;
});
;
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('pages/Game/game',["require", "exports", "../../scenes/cyberball", "../../models/settings-model", "phaser", "game/CyberballGameController", "game/CpuTargeting", "game/CyberballGameModel", "game/LeaveTriggers", "game/GameOverTriggers", "game/GameLog"], function (require, exports, cyberball_1, settings_model_1, phaser_1, CyberballGameController_1, CpuTargeting_1, CyberballGameModel_1, LeaveTriggers_1, GameOverTriggers_1, GameLog_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.GameViewModel = void 0;
    phaser_1 = __importStar(phaser_1);
    CyberballGameController_1 = __importDefault(CyberballGameController_1);
    CpuTargeting_1 = __importDefault(CpuTargeting_1);
    CyberballGameModel_1 = __importDefault(CyberballGameModel_1);
    LeaveTriggers_1 = __importDefault(LeaveTriggers_1);
    GameOverTriggers_1 = __importDefault(GameOverTriggers_1);
    class GameViewModel {
        constructor() {
            this.settings = (0, settings_model_1.defaultSettings)();
            this.gameWidth = 800;
            this.gameHeight = 460;
        }
        activate(params) {
            if ('settings' in params) {
                this.settings = new settings_model_1.SettingsModel(JSON.parse(atob(params.settings)));
            }
            if ('playerName' in params) {
                this.settings.player.name = params.playerName;
            }
            if (this.settings.hasPortraits) {
                this.gameHeight += this.settings.portraitHeight * 2 + this.settings.portraitPadding * 4;
            }
        }
        bind() {
            let cyberballGameController = new CyberballGameController_1.default(CyberballGameModel_1.default.humanPlayerId, this.settings.computerPlayers.length);
            (0, GameLog_1.addGameLogging)(cyberballGameController, this.settings);
            (0, CpuTargeting_1.default)(cyberballGameController, this.settings);
            (0, LeaveTriggers_1.default)(cyberballGameController, this.settings);
            (0, GameOverTriggers_1.default)(cyberballGameController, this.settings);
            let scene = new cyberball_1.CyberballScene(this.settings, cyberballGameController);
            this.gameConfig = {
                type: phaser_1.default.AUTO,
                width: this.gameWidth,
                height: this.gameHeight,
                scale: {
                    mode: phaser_1.Scale.ScaleModes.FIT
                },
                scene,
                physics: {
                    default: 'arcade'
                },
                dom: {
                    createContainer: true
                }
            };
        }
    }
    exports.GameViewModel = GameViewModel;
});
;
define('text!pages/Game/game.css',[],function(){return "canvas {\n    width: 100%;\n}\n\n.chat-log {\n    border: 1px solid black;\n    border-bottom: 0;\n    height: 100px;\n    overflow-y: auto;\n}\n\n.chat-input {\n    display: flex;\n}\n\n.chat-input input {\n    flex: 1;\n}\n\nphaser-game {\n    display: block;\n}\n\nbody {\n    margin: 0;\n}";});;
define('text!pages/Game/game.html',[],function(){return "<template>\n    <require from=\"./game.css\"></require>\n    <phaser-game config.bind=\"gameConfig\"></phaser-game>\n</template>\n";});;
define('text!pages/Home/ButtonTab.html',[],function(){return "<template>\n<div if.bind=\"activeTab === 'buttons'\" class=\"tabcontent\">\n    <div class=\"button-container\">\n        <button class=\"bottom-buttons\" click.delegate=\"testGame()\"><span>&#129514;</span><span>Open Game Preview</span></button>\n        \n\n        <button class=\"bottom-buttons\" click.delegate=\"openModal($event)\"><span>&#128190;</span><span>Save Preset</span></button>\n        <dialog class=\"new-sidebar\" id=\"preset_modal\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus click.delegate=\"cancelPresetSave()\">X</button>\n            <h2>Save Preset</h2>\n            <div class=\"input\">\n                <label>Preset Name:</label>\n                <input type=\"text\" value.bind=\"presetName\">\n            </div>\n            <div class=\"input\">\n                <label>Description:</label>\n                <textarea value.bind=\"presetDescription\"></textarea>\n            </div>\n            <button click.delegate=\"confirmPresetSave()\">Save</button>\n        </form></dialog>\n\n        <button class=\"bottom-buttons\" click.delegate=\"openModal($event)\"><span>&#128190;</span><span>Download</span></button>\n        <dialog class=\"new-sidebar\" id=\"file_modal\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus click.delegate=\"cancelFileSave()\">X</button>\n            <h2>Save As</h2>\n            <label>File Name:</label>\n            <input type=\"text\" value.bind=\"fileName\" placeholder=\"Enter filename\">\n            <button click.delegate=\"confirmFileSave()\">Save</button>\n        </form></dialog>\n\n        <button class=\"bottom-buttons\" click.delegate=\"copyIframeToClipboard()\"><span>&#10697;</span><span>Copy Embed Code</span></button>\n        <button class=\"bottom-buttons\" click.delegate=\"copyURL()\"><span>&#10697;</span><span>Copy Game URL</span></button>\n    </div>\n</div>\n</template>\n";});;
define('text!pages/Home/CpuTab.html',[],function(){return "<template>\n<div if.bind=\"activeTab === 'cpus'\">\n    <require from=\"resources/value-converters/json-value-converter\"></require>\n    <require from=\"resources/value-converters/integer-value-converter\"></require>\n    <require from=\"resources/value-converters/number-value-converter\"></require>\n    <require from=\"resources/value-converters/integer-array-value-converter\"></require>\n    <require from=\"resources/value-converters/flag-value-converter\"></require>\n\n    <div class=\"tab-container\">\n        <button repeat.for=\"cpu of settings.computerPlayers\"\n                class=\"tab ${$index === activeCPUTab ? 'active' : ''}\"\n                click.delegate=\"activeCPUTab = $index\">\n            Player ${$index + 2}\n        </button>\n    </div>\n    <h2>\n        CPUs <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n    </h2>\n    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n        <h3>Information</h3>\n        <p>The computer-controlled players the participant will play virtual ball-toss with.</p>\n    </form></dialog>\n    <div class=\"cpuButtons\">\n        <button class=\"bottom-buttons\" click.delegate=\"addCPU()\">+ Add CPU</button>\n        <button class=\"bottom-buttons ${settings.computerPlayers.length == 1 ? 'disabled' : ''}\"\n                click.delegate=\"removeCPU()\">- Remove CPU\n        </button>\n    </div>\n    <!-- Sub-tabs for each CPU -->\n\n\n    <!-- Details for each CPU -->\n    <div repeat.for=\"cpu of settings.computerPlayers\" if.bind=\"$index === activeCPUTab\">\n        <div class=\"two-column-grid\">\n            <label>Name</label>\n            <input type=\"text\" value.bind=\"cpu.name\"/>\n\n            <label>Tint Color <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>You can edit the color of the CPU player by clicking on the box next to <strong>Tint Color</strong> to bring up a color palette.</p>\n            </form></dialog>\n            <input type=\"color\" value.bind=\"cpu.tint\"/>\n\n            <!-- TODO: Reimplement portraits to either use a URL or implement image hosting service -->\n            <!-- <label>Portrait <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>You can insert an image that will be placed by the CPU in the game.</p>\n                <h4>Note</h4>\n                <p>Images must be smaller than 1MB</p>\n            </form></dialog>\n            <div class=\"portrait-div\">\n                <img class=\"portrait-img\" show.bind=\"cpu.portraitBuff\" src.bind=\"cpu.portraitBuff\">\n                <input type=\"file\" class=\"upload-buttons\" id=\"cpu-portrait-upload-${$index}\" value.bind=\"cpu.portrait\" change.delegate=\"cpuFileSelected(cpu, $event)\"/>\n                <label class=\"upload-labels\" for=\"cpu-portrait-upload-${$index}\">Choose File</label>\n                <button class=\"upload-labels\" click.delegate=\"clearCPUPortrait(cpu)\">Clear</button>\n            </div> -->\n            <label>Throw Delay (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>The amount of time the CPU stands in a “throw-ready” stance before throwing it.</p>\n            </form></dialog>\n            <input type=\"number\" value.bind=\"cpu.throwDelay | integer & updateTrigger:'blur'\" placeholder=\"Enter delay in milliseconds\"\n                    class=\"ms-input\"/>\n\n            <label>Throw Delay Variance (ms)<span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>A variance of 200 will result in the CPU standing in a “throw-ready” stance for +/- 200 milliseconds from a 500-millisecond Throw Delay (300 to 700 milliseconds).</p>\n            </form></dialog>\n            <input type=\"number\" value.bind=\"cpu.throwDelayVariance | integer & updateTrigger:'blur'\"\n                    placeholder=\"Enter delay in milliseconds\"/>\n\n            <label>Catch Delay (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>The amount of time the CPU stands in a “caught-ball” stance before preparing to throwing it.</p>\n            </form></dialog>\n            <input type=\"number\" value.bind=\"cpu.catchDelay | integer & updateTrigger:'blur'\" placeholder=\"Enter delay in milliseconds\"\n                   />\n\n            <label>Catch Delay Variance (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>A variance of 200 will result in the CPU standing with the ball for +/- 200-milliseconds from a 500-millisecond Catch Delay (300 to 700 milliseconds).</p>\n            </form></dialog>\n            <input type=\"number\" value.bind=\"cpu.catchDelayVariance | integer & updateTrigger:'blur'\" placeholder=\"Enter delay in milliseconds\"\n                   />\n\n\n        </div>\n\n        <h2>\n            Target Preference (%) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n            <br />\n            <span show.bind=\"shouldWarnTargetPref\" id=\"target-pref-total-warning\" class=\"warning\">Target Preferences must add up to 100</span>\n        </h2>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>The percentage of throws that the CPU will distribute to other CPUs and the participant.</p>\n        </form></dialog>\n        </h2>\n        <div class=\"two-column-grid target-preference\" repeat.for=\"pref of cpu.targetPreference\">\n            <label>${getPlayerNumber($index, $parent.$index)}</label>\n            <input type=\"number\" value.bind=\"cpu.targetPreference[$index] | integer & updateTrigger: 'blur'\" blur.trigger=\"checkTargetPrefTotal(cpu)\" />\n        </div>\n\n        <h2>Leave Triggers <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></h2>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>When the CPU will leave the game.</p>\n            <h4>Note</h4>\n            <p><strong>Chance</strong> refers to the probability the CPU will leave at the programmed point. E.g., setting <strong>Chance</strong> for leaving at 50% means the CPU will leave 50% of the time.</p>\n        </form></dialog>\n        <div class=\"leave-triggers-grid\">\n            <input type=\"checkbox\"\n                checked.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:1\"/>\n            <label>\n                Throws Elapsed\n                <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n            </label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>The number of throws between all players before the CPU leaves.</p>\n            </form></dialog>\n            <div class=\"column\" if.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:1\">             \n                <label class=\"two-column-grid-even\">\n                    <span>Leave Threshold</span>\n                    <input type='number' value.bind=\"cpu.leaveTurn | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Variance <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                        <h3>Information</h3>\n                        <p>A variance of 2 means the CPU will leave the game +/- 2 throws from a 10 Throws Elapsed Threshold (8 to 12 throws).</p>\n                    </form></dialog>\n                    <input type=\"number\" value.bind=\"cpu.leaveTurnVariance | integer & updateTrigger:'blur'\">\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Chance (%)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveTurnChance | integer & updateTrigger:'blur'\"/>\n                </label>\n            </div>\n\n            <input type=\"checkbox\"\n                    checked.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:2\"/>\n            <label>\n                Time Elapsed\n                <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n            </label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>How much time passes before the CPU leaves.</p>\n            </form></dialog>\n            <div class=\"column\" if.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:2\">             \n                <label class=\"two-column-grid-even\">\n                    <span>Leave Threshold (ms)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveTime | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Variance (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                        <h3>Information</h3>\n                        <p>A variance of 30 means the CPU will leave the game +/- 30 seconds from a 120-second Time Elapsed Threshold (between 90 to 150 seconds).</p>\n                    </form></dialog>\n                    <input type=\"number\" value.bind=\"cpu.leaveTimeVariance | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Chance (%)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveTimeChance | integer & updateTrigger:'blur'\"/>\n                </label>\n            </div>\n\n            <input type=\"checkbox\"\n                    checked.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:4\"/>\n            <label>\n                Throws Ignored\n                <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n            </label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>How many throws occur only between the other CPUs and participant before the CPU leaves.</p>\n            </form></dialog>\n            <div class=\"column\" if.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:4\">             \n                <label class=\"two-column-grid-even\">\n                    <span>Leave Threshold</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveIgnored | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Variance <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                        <h3>Information</h3>\n                        <p>A variance of 2 means the CPU will leave the game +/- 2 throws from a 10 Throws Ignored Threshold (8 to 12 throws).</p>\n                    </form></dialog>\n                    <input type=\"number\" value.bind=\"cpu.leaveIgnoredVariance | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Chance (%)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveIgnoredChance | integer & updateTrigger:'blur'\"/>\n                </label>\n            </div>\n\n            <input type=\"checkbox\"\n                    checked.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:16\"/>\n            <label>\n                Time Ignored\n                <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n            </label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>How much time the other CPUs and participant spend only throwing to each other before the CPU leaves.</p>\n            </form></dialog>\n            <div class=\"column\" if.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:16\">             \n                <label class=\"two-column-grid-even\">\n                    <span>Leave Threshold (ms)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveTimeIgnored | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Variance (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                        <h3>Information</h3>\n                        <p>A variance of 15 means the CPU will leave the game +/- 15 seconds from a 45-second Ignored Time Threshold (30 to 60 seconds).</p>\n                    </form></dialog>\n                    <input type=\"number\" value.bind=\"cpu.leaveTimeIgnoredVariance | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Chance (%)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveTimeIgnoredChance | integer & updateTrigger:'blur'\"/>\n                </label>\n            </div>\n\n            <input type=\"checkbox\"\n                    checked.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:8\"/>\n            <label>\n                Other Players Leaving\n                <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n            </label>\n            <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>The number of other CPUs that must leave before the CPU leaves.</p>\n            </form></dialog>\n            <div class=\"column\" if.bind=\"cpu.leaveTrigger | flag:cpu.leaveTrigger:8\">\n                <label class=\"two-column-grid-even\">\n                    <span>Leave Threshold</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveOtherLeaver | integer & updateTrigger:'blur'\"/>\n                </label>\n                <label class=\"two-column-grid-even\">\n                    <span>Chance (%)</span>\n                    <input type=\"number\" value.bind=\"cpu.leaveOtherLeaverChance | integer & updateTrigger:'blur'\"/>\n                </label>\n            </div>\n        </div>\n    </div>\n</div>\n</template>\n";});;
define('text!pages/Home/GameplayTab.html',[],function(){return "<template>\n<div if.bind=\"activeTab === 'gameplay'\" class=\"tabcontent\">\n    <require from=\"resources/value-converters/integer-value-converter\"></require>\n    <h2>Gameplay</h2>\n    <div clas=\"input\">\n    <div class=\"two-column-grid\">\n        <label for=\"selectedGameOverCondition\">Select game end condition:</label>\n        <select id=\"selectedGameOverCondition\" value.bind=\"settings.selectedGameOverCondition\">\n            <option repeat.for=\"condition of settings.gameOverConditions\" model.bind=\"condition.id\">${condition.label}</option>\n        </select>\n\n        <label>Throw Count <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>How many throws between all players before the game ends.</p>\n        </form></dialog>\n        <input type=\"number\" value.bind=\"settings.throwCount | integer & updateTrigger:'blur'\" blur.trigger=\"checkEmptyNumber($event)\"/>\n\n\n        <label>Time Limit (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>How long the game is played before it ends.</p>\n        </form></dialog>\n        <input type=\"number\" value.bind=\"settings.timeLimit | integer & updateTrigger:'blur'\" blur.trigger=\"checkEmptyNumber($event)\"/>\n\n        <label>Display Time Limit<span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>Allow the participant to see how much time remains in the game at the top right corner of the screen.</p>\n        </form></dialog>\n        <input type=\"checkbox\" checked.bind=\"settings.displayTimeLimit\"/>\n\n        <label>Time Limit Label</label>\n        <input type=\"text\" value.bind=\"settings.timeLimitText\" />\n\n        <label>Ball Speed <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>The speed at which the ball travels between players.</p>\n            <h4>Note</h4>\n            <p>A higher value will result in the ball moving faster between players.</p>\n        </form></dialog>\n        <input type=\"number\" value.bind=\"settings.ballSpeed | integer & updateTrigger:'blur'\"\n                blur.trigger=\"checkEmptyNumber($event)\"/>\n\n        <label>Ball Tint Color <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>You can edit the color of the ball by clicking on the box next to <strong>Ball Tint Color</strong> to bring up a color palette.</p>\n        </form></dialog>\n        <input type=\"color\" value.bind=\"settings.ballTint\"/>\n\n        <!-- TODO: Reimplement portraits to either use a URL or implement image hosting service -->\n        <!-- <label>Portrait Height (px) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>Adjusts the portrait size of all players.</p>\n        </form></dialog>\n        <input type=\"number\" value.bind=\"settings.portraitHeight | integer & updateTrigger:'blur'\"\n                blur.trigger=\"checkEmptyNumber($event)\"/> -->\n\n        <label>Use Schedule <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>Allows you to decide on a throw-by-throw basis when each player will receive the ball.</p>\n            <p>Each CPU player needs to be given a schedule starting with 2 then 3 etc. A schedule should contain rows of text in the following form:</p>\n            <code>2,13,3,3,3,3</code>\n            <p>\n                The first number indicates which player the schedule is for. The subsequent numbers indicate which players the CPU will throw to. \n                For example, <code style=\"display: inline;\">13</code> in the example above means that CPU 2 will throw to player 1 (the human player) and player 3 in their first 2 throws (with a randomized order).\n            </p>\n        </form></dialog>\n        <input type=\"checkbox\" checked.bind=\"settings.useSchedule\"/>\n\n        <label if.bind=\"settings.useSchedule\">Schedule</label>\n        <!-- <textarea value.bind=\"settings.schedule | integerArray & updateTrigger:'blur'\"></textarea> -->\n        <textarea if.bind=\"settings.useSchedule\" value.bind=\"settings.scheduleText  & updateTrigger:'blur'\"></textarea>\n\n        <label>Schedule Honors Throw Count <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>Sets the value in the throw count to override the number of throws placed in scheduler while allowing the order of the scheduler’s values to also occur.</p>\n            <h4>Note</h4>\n            <p>With this option on, a value of 10 in the Throw Count box, along with 20 values placed in the Schedule, will result in a game with 10 throws that follows a shortened schedule.</p>\n        </form></dialog>\n        <input type=\"checkbox\" checked.bind=\"settings.scheduleHonorsThrowCount\"/>\n\n        <label>Game Over Text <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>The text that will appear when the game ends.</p>\n        </form></dialog>\n        <input type=\"text\" value.bind=\"settings.gameOverText\"/>\n\n        <label>Game Over Opacity (%) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>How transparent the background behind the Game Over text is.</p>\n            <h4>Note</h4>\n            <p>A higher percentage will result in more of the screen behind the Game Over text to be less visible. The background will be less transparent.</p>\n        </form></dialog>\n        <div class=\"range-container\">\n            <input\n                type=\"range\"\n                min=\"0\"\n                max=\"100\"\n                step=\"1\"\n                value.bind=\"sliderValue\"\n                change.delegate=\"updateOpacity()\"\n            />\n            <span class=\"range-value\">${sliderValue}%</span>\n        </div>\n    </div>\n</div>\n</template>\n";});;
define('text!pages/Home/PlayerTab.html',[],function(){return "<template>\n<div if.bind=\"activeTab === 'player'\" class=\"tabcontent\">\n    <require from=\"resources/value-converters/json-value-converter\"></require>\n    <require from=\"resources/value-converters/integer-value-converter\"></require>\n    <require from=\"resources/value-converters/number-value-converter\"></require>\n    <require from=\"resources/value-converters/integer-array-value-converter\"></require>\n    <require from=\"resources/value-converters/flag-value-converter\"></require>\n\n    <h2>Human <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></h2>\n    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n        <h3>Information</h3>\n        <p>This is the player the participant in your study will control.</p>\n    </form></dialog>\n\n    <div class=\"two-column-grid\">\n        <label>Name</label>\n        <input type=\"text\" value.bind=\"settings.player.name\"/>\n\n        <!-- TODO: Reimplement portraits to either use a URL or implement image hosting service -->\n        <!-- <label>Portrait <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                <h3>Information</h3>\n                <p>You can insert an image that will be placed below the participant in the game.</p>\n                <h4>Note</h4>\n                <p>Images must be smaller than 1MB</p>\n        </form></dialog>\n        <div class=\"portrait-div\">\n            <img class=\"portrait-img\" show.bind=\"settings.player.portraitBuff\" src.bind=\"settings.player.portraitBuff\">\n            <input type=\"file\" class=\"upload-buttons\" id=\"player-portrait-upload\" value.bind=\"settings.player.portrait\" change.delegate=\"fileSelected($event)\">\n            <label class=\"upload-labels\" for=\"player-portrait-upload\">Choose File</label>\n            <button class=\"upload-labels\" click.delegate=\"clearPlayerPortrait()\">Clear</button>\n        </div> -->\n        <label>Tint Color <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>You can edit the color of the participant’s player by clicking on the box next to <strong>Tint Color</strong> to bring up a color palette.</p>\n        </form></dialog>\n        <input type=\"color\" value.bind=\"settings.player.tint\"/>\n\n    </div>\n    <h2>Leave Triggers <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></h2>\n    <dialog class=\"new-sidebar\"><form method=\"dialog\">\n        <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n        <h3>Information</h3>\n        <p>When a <strong>Leave Game</strong> button appears that participants can click to end the game.</p>\n        <h4>Note</h4>\n        <p>“Variance” refers to the ability to deviate (+/-) away from the set value.</p>\n    </form></dialog>\n    <div class=\"leave-triggers-grid\">\n        <input type=\"checkbox\"\n                checked.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:1\"/>\n        <label>\n            Throws Elapsed\n            <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n        </label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>The number of throws between all players before the <strong>Leave Game</strong> button appears.</p>\n        </form></dialog>\n        <div class=\"column\" if.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:1\">\n            <label class=\"two-column-grid-even\">\n                <span>Leave Threshold</span>\n                <input type=\"number\" value.bind=\"settings.player.leaveTurn | integer & updateTrigger:'blur'\"/>\n            </label>\n            <label class=\"two-column-grid-even\">\n                <span>Variance <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                    <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                    <h3>Information</h3>\n                    <p>A variance of 2 means participants will be given the <strong>Leave Game</strong> button +/- 2 throws from a 10 Throws Elapsed Threshold (8 to 12 throws).</p>\n                </form></dialog>\n                <input type=\"number\" value.bind=\"settings.player.leaveTurnVariance | integer & updateTrigger:'blur'\"/>\n            </label>\n        </div>\n\n        <input type=\"checkbox\"\n                checked.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:2\"/>\n        <label>\n            Time Elapsed\n            <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n        </label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>How long the game is played before the <strong>Leave Game</strong> button appears.</p>\n        </form></dialog>\n        <div class=\"column\" if.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:2\">\n            <label class=\"two-column-grid-even\">\n                <span>Leave Threshold (ms)</span>\n                <input type=\"number\" value.bind=\"settings.player.leaveTime | integer & updateTrigger:'blur'\"/>\n            </label>\n            <label class=\"two-column-grid-even\">\n                <span>Variance (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                    <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                    <h3>Information</h3>\n                    <p>A variance of 30 means participants will be given the <strong>Leave Game</strong> button +/- 30 seconds from a 120-second Time Elapsed Threshold (between 90 to 150 seconds).</p>\n                </form></dialog>\n                <input type=\"number\" value.bind=\"settings.player.leaveTimeVariance | integer & updateTrigger:'blur'\"/>\n            </label>\n        </div>\n\n        <input type=\"checkbox\"\n                checked.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:4\"/>\n        <label>\n            Throws Ignored\n            <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n        </label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>How many throws occur only between the CPUs before the <strong>Leave Game</strong> button appears for the participant.</p>\n        </form></dialog>\n        <div class=\"column\" if.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:4\">\n            <label class=\"two-column-grid-even\">\n                <span>Leave Threshold</span>\n                <input type=\"number\" value.bind=\"settings.player.leaveIgnored | integer & updateTrigger:'blur'\"/>\n                \n            </label>\n            <label class=\"two-column-grid-even\">\n                <span>Variance <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                    <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                    <h3>Information</h3>\n                    <p>A variance of 2 means participants will be given the <strong>Leave Game</strong> button +/- 2 throws from a 10 Throws Ignored Threshold (8 to 12 throws).</p>\n                </form></dialog>\n                <input type=\"number\" value.bind=\"settings.player.leaveIgnoredVariance | integer & updateTrigger:'blur'\"/>\n            </label>\n        </div>\n\n        <input type=\"checkbox\"\n                checked.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:16\"/>\n        <label>\n            Time Ignored\n            <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n        </label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>How much time the CPUs spend throwing to each other before the <strong>Leave Game</strong> button appears for the participant.</p>\n        </form></dialog>\n        <div class=\"column\" if.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:16\">\n            <label class=\"two-column-grid-even\">\n                <span>Leave Threshold (ms)</span>\n                <input type=\"number\" value.bind=\"settings.player.leaveTimeIgnored | integer & updateTrigger:'blur'\"/>\n                \n            </label>\n            <label class=\"two-column-grid-even\">\n                <span>Variance (ms) <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span></span>\n                <dialog class=\"new-sidebar\"><form method=\"dialog\">\n                    <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n                    <h3>Information</h3>\n                    <p>A variance of 15 means participants will be given the <strong>Leave Game</strong> button +/- 15 seconds from a 45-second Ignored Time Threshold (30 to 60 seconds).</p>\n                </form></dialog>\n                <input type=\"number\" value.bind=\"settings.player.leaveTimeIgnoredVariance | integer & updateTrigger:'blur'\"/>\n            </label>\n        </div>\n\n        <input type=\"checkbox\"\n                checked.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:8\"/>\n        <label>\n            Other Players Leaving\n            <span class=\"tooltip-icon h2-tooltip\" click.delegate=\"openModal($event)\">?</span>\n        </label>\n        <dialog class=\"new-sidebar\"><form method=\"dialog\">\n            <button class=\"close-btn\" autofocus type=\"submit\">X</button>\n            <h3>Information</h3>\n            <p>The number of CPUs that must leave before the <strong>Leave Game</strong> button appears for the participant.</p>\n        </form></dialog>\n        <div class=\"column\" if.bind=\"settings.player.leaveTrigger | flag:settings.player.leaveTrigger:8\">\n            <label>\n                <span>Leave Threshold</span>\n                <input type=\"number\" value.bind=\"settings.player.leaveOtherLeaver | integer & updateTrigger:'blur'\"/>\n            </label>\n        </div>\n    </div>\n</div>\n</template>\n";});;
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('pages/Home/home',["require", "exports", "aurelia-templating-resources", "aurelia-framework", "models/settings-model", "models/cpu-settings-model", "clipboard", "../Setting-Service"], function (require, exports, aurelia_templating_resources_1, aurelia_framework_1, settings_model_1, cpu_settings_model_1, clipboard_1, Setting_Service_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.HomeViewModel = void 0;
    clipboard_1 = __importDefault(clipboard_1);
    let HomeViewModel = class HomeViewModel {
        updateOpacity() {
            this.settings.gameOverOpacity = this.sliderValue / 100;
        }
        activeCPUTabChanged(index) {
            this.checkTargetPrefTotal(this.settings.computerPlayers[index]);
        }
        constructor(signaler, settingsService) {
            this.signaler = signaler;
            this.settingsService = settingsService;
            this.activeTab = 'player';
            this.settings = (0, settings_model_1.defaultSettings)();
            this.activeCPUTab = 0;
            this.currentSetting = '';
            this.presetName = '';
            this.presetDescription = '';
            this.fileName = '';
            this.shouldWarnTargetPref = false;
            this.sliderValue = this.settings.gameOverOpacity;
        }
        getNumberOrZero(value) {
            return value === null || isNaN(value) ? 0 : Number(value);
        }
        refreshIframe() {
            this.convertStringsToNumbers(this.settings);
            const iframe = document.getElementById('gamePreview');
            iframe.src = this.url;
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.location.reload();
            }
        }
        bind() {
            this.clipboard = new clipboard_1.default('#copy');
        }
        unbind() {
            this.clipboard.destroy();
        }
        addCPU() {
            this.settings.computerPlayers.push(new cpu_settings_model_1.CpuSettingsModel({
                name: `Player ${this.settings.computerPlayers.length + 2}`,
            }));
            this.settings.computerPlayers.forEach(cpu => {
                while (cpu.targetPreference.length != this.settings.computerPlayers.length)
                    cpu.targetPreference.push(0);
            });
            this.activeCPUTab = this.settings.computerPlayers.length - 1;
        }
        removeCPU() {
            if (this.settings.computerPlayers.length > 1) {
                this.settings.computerPlayers.pop();
                this.settings.computerPlayers.forEach(cpu => {
                    cpu.targetPreference.pop();
                });
                if (this.activeCPUTab >= this.settings.computerPlayers.length) {
                    this.activeCPUTab = this.settings.computerPlayers.length - 1;
                }
            }
        }
        getPlayerNumber(index, parent_index) {
            if (index === 0)
                return "Human";
            else if (index > parent_index)
                return "CPU Player " + (index + 2);
            else
                return "CPU Player " + (index + 1);
        }
        checkTargetPrefTotal(cpu) {
            let sum = cpu.targetPreference.reduce((sum, value) => sum + value);
            this.shouldWarnTargetPref = sum < 99.9 || sum > 100.1;
        }
        saveSettings() {
            this.signaler.signal('save-settings');
        }
        get url() {
            let url = document.location.origin + document.location.pathname;
            url += '#game?settings=';
            url += btoa(JSON.stringify(this.settings));
            return url;
        }
        testGame() {
            this.convertStringsToNumbers(this.settings);
            window.open(this.url);
        }
        copyURL() {
            navigator.clipboard.writeText(this.url);
        }
        convertStringsToNumbers(obj) {
            for (let key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if (typeof obj[key] === 'string' && !isNaN(obj[key]) && obj[key].trim() !== '') {
                        obj[key] = Number(obj[key]);
                    }
                    else if (obj[key] instanceof Object) {
                        this.convertStringsToNumbers(obj[key]);
                    }
                }
            }
        }
        get clipboardText() {
            return JSON.stringify(this.settings, null, 2);
        }
        copyIframeToClipboard() {
            const iframeString = `<iframe id="cyberball" width="100%" height="580" src="${this.url}"></iframe>`;
            navigator.clipboard.writeText(iframeString);
        }
        checkEmptyNumber(e) {
            let inputElement = e.target;
            if (inputElement.value.length === 0 && inputElement.type === 'number') {
                inputElement.value = "0";
            }
        }
        updateUrl() {
            const iframe = document.getElementById('gamePreview');
            iframe.src = this.url;
            console.log(this.settings);
        }
        fileSelected(e) {
            let reader = new FileReader();
            let file = e.target.files[0];
            if (file.size > 1000000) {
                alert('Portraits greater than 1MB are not allowed as they can cause lag!');
                this.clearPlayerPortrait();
                return;
            }
            reader.readAsDataURL(file);
            this.fileName = file.name;
            reader.onload = () => {
                console.log(reader.result);
                this.settings.player.portraitBuff = reader.result;
                this.updateUrl();
            };
        }
        cpuFileSelected(cpu, e) {
            console.log(cpu);
            let reader = new FileReader();
            let file = e.target.files[0];
            if (file.size > 1000000) {
                alert('Portraits greater than 1MB are not allowed as they can cause lag!');
                this.clearCPUPortrait(cpu);
                return;
            }
            reader.readAsDataURL(file);
            this.fileName = file.name;
            reader.onload = () => {
                console.log(reader.result);
                cpu.portraitBuff = reader.result;
                this.updateUrl();
            };
        }
        clearPlayerPortrait() {
            this.settings.player.portrait = null;
            this.settings.player.portraitBuff = null;
        }
        clearCPUPortrait(cpu) {
            cpu.portrait = null;
            cpu.portraitBuff = null;
        }
        previewGame() {
            const gamePreviewUrl = this.url;
            const iframe = document.getElementById('gamePreview');
            iframe.src = 'about:blank';
            iframe.src = gamePreviewUrl;
        }
        attached() {
            if (this.settingsService.settings) {
                this.settings = this.settingsService.settings;
            }
            this.previewGame();
        }
        convertToMap(str) {
            const lines = str.split('\n');
            const map = new Map();
            for (const line of lines) {
                const [key, ...values] = line.split(',').map(Number);
                map.set(key, values);
            }
            return map;
        }
        nextTab() {
            if (this.activeTab === 'player') {
                this.activeTab = 'cpus';
                this.settings.computerPlayers.forEach(cpu => {
                    cpu.portrait = "";
                });
            }
            else if (this.activeTab === 'cpus') {
                this.activeTab = 'gameplay';
            }
            else if (this.activeTab === 'gameplay') {
                this.activeTab = 'buttons';
            }
        }
        previousTab() {
            if (this.activeTab === 'buttons') {
                this.activeTab = 'gameplay';
            }
            else if (this.activeTab === 'gameplay') {
                this.activeTab = 'cpus';
                this.settings.computerPlayers.forEach(cpu => {
                    cpu.portrait = "";
                });
            }
            else if (this.activeTab === 'cpus') {
                this.activeTab = 'player';
            }
        }
        get settingsForPreview() {
            return this.settings;
        }
        cancelPresetSave() {
            document.getElementById("preset_modal").close();
            this.presetName = '';
            this.presetDescription = '';
        }
        confirmPresetSave() {
            if (this.presetName.trim() === '') {
                alert('Please enter a preset name.');
                return;
            }
            this.convertStringsToNumbers(this.settings);
            const presetData = {
                description: this.presetDescription,
                settings: this.settings
            };
            localStorage.setItem(this.presetName, JSON.stringify(presetData));
            document.getElementById("preset_modal").close();
            this.presetName = '';
            this.presetDescription = '';
        }
        cancelFileSave() {
            document.getElementById("file_modal").close();
            this.fileName = '';
        }
        confirmFileSave() {
            if (this.fileName.trim() === '') {
                alert('Please enter a file name.');
                return;
            }
            this.convertStringsToNumbers(this.settings);
            const settingsString = JSON.stringify(this.settings, null, 2);
            const blob = new Blob([settingsString], { type: 'text/plain;charset=utf-8' });
            const a = document.createElement('a');
            const url = window.URL.createObjectURL(blob);
            a.href = url;
            a.download = this.fileName.endsWith('.txt') ? this.fileName : `${this.fileName}.txt`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            document.getElementById("file_modal").close();
            this.fileName = '';
        }
        openModal(event) {
            event.target.parentElement.nextElementSibling.showModal();
        }
    };
    __decorate([
        aurelia_framework_1.observable,
        __metadata("design:type", Object)
    ], HomeViewModel.prototype, "activeCPUTab", void 0);
    __decorate([
        aurelia_framework_1.bindable,
        __metadata("design:type", Object)
    ], HomeViewModel.prototype, "sliderValue", void 0);
    __decorate([
        (0, aurelia_framework_1.computedFrom)('settings', 'settings.player', 'settings.computerPlayers', 'settings.someOtherProperty', 'settings.anotherProperty'),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], HomeViewModel.prototype, "settingsForPreview", null);
    HomeViewModel = __decorate([
        (0, aurelia_framework_1.autoinject)(),
        __metadata("design:paramtypes", [aurelia_templating_resources_1.BindingSignaler, Setting_Service_1.SettingsService])
    ], HomeViewModel);
    exports.HomeViewModel = HomeViewModel;
});
;
define('text!pages/Home/home.css',[],function(){return "select {\n    border: 1px solid #ccc; /* Add a border */\n    border-radius: 4px; /* Add some rounded corners */\n}\n\na {\n    text-decoration: none;\n    padding: 8px 16px;\n}\n\na:hover {\n    background-color: #9d9d9d;\n    color: black;\n}\n\n.previous, .next {\n    background-color: #ddd;\n    color: black;\n    position: absolute;\n    top: 50%;  /* This will center the button vertically */\n    border-radius: 50%;\n}\n\n.previous {\n    left: 6px;\n}\n\n.next {\n    right: 6px;\n}\n\n.button-container {\n    width: max-content;\n    display: grid;\n    grid-template-columns: 1fr;\n    gap: 0.5em;\n    margin: 0 auto;\n}\n\n.button-container button {\n    text-align: left;\n    display: flex;\n    gap: 1em;\n}\n\n.button-container > div {\n    display: grid;\n    grid-template-columns: 1fr max-content;\n    gap: 0.5em;\n}\n\n.clipboard-container {\n    position: relative;\n}\n\n.popup {\n    display: none;\n    position: absolute;\n    width: max-content;\n    top: -100%;\n    transform: translateX(-20%);\n    background-color: #007BFF25;\n    color: #003d80;\n    padding: 0.5em;\n    border-radius: 5px;\n}\n\n.h2-tooltip {\n    font-size: 1rem;\n    vertical-align: middle;\n}\n\n.description-header {\n    font-weight: bold;\n    text-decoration: underline;\n    margin-bottom: 8px; /* Add space below the headers */\n    display: block; /* Ensure each header is on a new line */\n}\n\n.column {\n    display: flex;\n    flex-direction: column;\n}\n\n#home-button {\n    position: absolute;\n    top: 10px;\n    left: 10px;\n    padding: 5px 10px;\n    font-size: 14px;\n}\n#home-button:hover {\n    color: white;\n}\n\n.bottom-buttons {\n    background-color: #007BFF;\n    color: #FFFFFF;\n    padding: 10px 20px;\n    border: none;\n    border-radius: 5px;\n    font-size: 16px;\n    cursor: pointer;\n    transition: background-color 0.3s ease;\n    justify-content: center;\n}\n\n.refresh-button {\n    position: absolute;      /* Positioning relative to the container */\n    bottom: 10px;            /* Distance from the bottom */\n    left: 10px;              /* Distance from the left */\n    padding: 5px 10px;       /* Smaller padding */\n    font-size: 14px;         /* Smaller font size */\n}\n\n.bottom-buttons:hover {\n    background-color: #0056b3;\n}\n\n.bottom-buttons:active {\n    background-color: #003d80;\n}\n\n.bottom-buttons:focus {\n    outline: none;\n    box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.5);\n}\n\n/* Container for the tabs */\n.tab-container {\n    margin-top: 20px;\n    display: flex;\n    flex-wrap: wrap;\n    gap: 10px;\n}\n\n/* Individual tabs */\n.tab {\n    padding: 10px 15px; /* Adjust padding to your preference */\n    margin: 0;\n    box-sizing: border-box;\n    background-color: #007bff; /* This is a generic blue, replace with your specific blue color */\n    border: none; /* Remove default border */\n    border-radius: 5px; /* Rounded corners for a button-like appearance */\n    color: white; /* White text color for contrast */\n    cursor: pointer; /* Changes the cursor to indicate the tab is clickable */\n    text-align: center; /* Center the text inside the tab/button */\n    font-weight: bold; /* Makes the text bold */\n    transition: background-color 0.3s ease; /* Smooth transition for hover effect */\n}\n\n/* Hover effect for tabs */\n.tab:hover {\n    background-color: #0056b3; /* Darker blue on hover, adjust the color to match your design */\n}\n\n/* Active tab style */\n.tab.active {\n    background-color: #004080; /* Even darker blue for the active tab */\n    color: #fff;\n}\n\n/* Responsive adjustment for smaller screens */\n@media (max-width: 600px) {\n    .tab {\n        flex: 0 0 100%;\n    }\n}\n\niframe {\n    pointer-events: auto;\n}\n\n.tooltip-icon {\n    display: inline-block;\n    width: 20px;\n    height: 20px;\n    background-color: #007BFF;\n    color: #FFFFFF;\n    border-radius: 50%;\n    text-align: center;\n    line-height: 20px;\n    cursor: pointer;\n}\n\n.cpuButtons {\n    margin-bottom: 10px;\n}\n\n.configHeader {\n    text-align: center;\n}\n\ndialog.new-sidebar {\n    margin: auto;\n    border: none;\n    box-shadow: 5px 5px 10px 0 black;\n    max-width: 35rem;\n}\n\n.close-btn {\n    position: absolute;\n    top: 10px;\n    right: 10px;\n    background-color: #FF0000;\n    color: #FFFFFF;\n    border: none;\n    border-radius: 50%;\n    width: 25px;\n    height: 25px;\n    text-align: center;\n    line-height: 25px;\n    cursor: pointer;\n}\n\n.modal-buttons {\n    display: flex;\n    justify-content: space-between;\n    margin-top: 20px;\n}\n\n.two-column-grid {\n    display: grid;\n    grid-template-columns: 1fr 1fr;\n}\n\n.leave-triggers-grid {\n    display: grid;\n    grid-template-columns: auto 1fr;\n}\n\n.leave-triggers-grid .column {\n    grid-column: 1 / span 2;\n}\n\n.two-column-grid-even {\n    display: grid;\n    grid-template-columns: 1fr 1fr;\n}\n\n.two-column-grid *, .leave-triggers-grid * {\n    margin: 0.2em 0.5em;\n}\n\n.two-column-grid * {\n    margin: 0.2em 0.5em;\n}\n\ninput[type=\"checkbox\"] {\n    margin-right: auto;\n}\n\ninput[type=\"file\"] {\n    display: none;\n}\n\n.upload-buttons {\n    display: grid;\n}\n\n.upload-labels {\n    display: grid;\n    background-color: #007BFF;\n    color: #FFFFFF;\n    padding: 5px 5px;\n    border: none;\n    border-radius: 5px;\n    font-size: 14px;\n    cursor: pointer;\n    transition: background-color 0.3s ease;\n    justify-content: center;\n}\n\n.portrait-div {\n    margin: 0;\n    margin-bottom: 0.5em;\n}\n\n.portrait-img {\n    max-width: 300px;\n}\n\ninput[type=\"file\"] {\n    display: none;\n}\n\n.upload-buttons {\n    display: grid;\n}\n\n.upload-labels {\n    display: grid;\n    background-color: #007BFF;\n    color: #FFFFFF;\n    padding: 5px 5px;\n    border: none;\n    border-radius: 5px;\n    font-size: 14px;\n    cursor: pointer;\n    transition: background-color 0.3s ease;\n    justify-content: center;\n}\n\n.portrait-div {\n    margin: 0;\n    margin-bottom: 0.5em;\n}\n\n.portrait-img {\n    max-width: 300px;\n}\n\n.target-preference-list {\n    display: flex;\n    flex-direction: column;\n}\n\n.target-preference-list input {\n    width: fit-content;\n}\n\n.warning {\n    font-size: .625em;\n    color: red;\n    text-align: center;\n}\n";});;
define('text!pages/Home/home.html',[],function(){return "<template>\n    <require from=\"./home.css\"></require>\n    <require from=\"../LandingPage/LandingPage.css\"></require>\n\n    <div class=\"landing-page\">\n        <img src=\"../../../assets/player.png\" alt=\"Cyberball Sprite\" class=\"welcome-image\">\n        <h1 class=\"configHeader\">Cyberball Configuration Builder</h1>\n        <div class=\"content\">\n            <iframe id=\"gamePreview\"></iframe>\n            <div class=\"container\">\n                <a id=\"home-button\" class=\"bottom-buttons\" href=\"./\">Return to Landing Page</a>\n                <compose view=\"./PlayerTab.html\"></compose>\n                <compose view=\"./CpuTab.html\"></compose>\n                <compose view=\"./GameplayTab.html\"></compose>\n                <compose view=\"./ButtonTab.html\"></compose>\n                <button class=\"refresh-button bottom-buttons\" click.delegate=\"refreshIframe()\">Refresh Iframe</button>\n                <a href=\"#\" if.bind=\"activeTab !== 'player'\" class=\"previous round\" click.delegate=\"previousTab()\">\n                    &#8249;\n                </a>\n                <a href=\"#\" if.bind=\"activeTab !== 'buttons'\" class=\"next round\" click.delegate=\"nextTab()\">\n                    &#8250;\n                </a>\n            </div>\n        </div>\n    </div>\n</template>\n";});;
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define('pages/LandingPage/LandingPage',["require", "exports", "aurelia-framework", "aurelia-router"], function (require, exports, aurelia_framework_1, aurelia_router_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LandingPage = void 0;
    let LandingPage = class LandingPage {
        constructor(router) {
            this.router = router;
        }
        startFromScratch() {
            console.log(this.router);
            this.router.navigateToRoute('home');
        }
        loadPreset() {
            console.log(this.router);
            this.router.navigateToRoute('PresetPage');
        }
        openManual() {
            console.log("Opening manual...");
        }
    };
    LandingPage = __decorate([
        (0, aurelia_framework_1.inject)(aurelia_router_1.Router),
        __metadata("design:paramtypes", [Object])
    ], LandingPage);
    exports.LandingPage = LandingPage;
});
;
define('text!pages/LandingPage/LandingPage.css',[],function(){return "body {\n    font-family: Arial, sans-serif;\n    margin: 0;\n    background-color: #f7f7f7;\n}\n\n.content {\n    display: grid;\n    grid-template-columns: repeat( auto-fit, minmax(450px, 1fr) );\n    place-items: center;\n    align-items: flex-start;\n    padding: 1em;\n    gap: 0.5em;\n}\n\n.container {\n    width: clamp(20%, max-content, 80%);\n    background-color: #ffffff;\n    padding: 50px;\n    border-radius: 10px;\n    box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.1);\n    position: relative;\n}\n\n.container h2 {\n    text-align: center;\n}\n\niframe {\n    border: none;\n    width: 100%;\n    min-height: 30vh;\n    height: 100%;\n    overflow: hidden;\n}\n\n.welcome-image {\n    width: 40%;\n    display: block;\n    margin: 0 auto;\n    padding: 1em;\n}\n\nh1 {\n    margin-bottom: 30px;\n    color: #333;\n}\n\n.btn {\n    padding: 10px 20px;\n    margin: 5px;\n    border-radius: 5px;\n    background-color: #007BFF;\n    color: #ffffff;\n    cursor: pointer;\n    transition: background-color 0.3s ease;\n    text-decoration: none;\n}\n\n.btn:hover {\n    background-color: #0056b3;\n}\n";});;
define('text!pages/LandingPage/LandingPage.html',[],function(){return "<template>\n    <require from=\"./LandingPage.css\"></require>\n\n    <div class=\"landing-page\">\n        <head>\n            <meta charset=\"UTF-8\">\n\n            <title>Welcome to Cyberball</title>\n        </head>\n        <body>\n        <img src=\"../../../assets/player.png\" alt=\"Cyberball Sprite\" class=\"welcome-image\">\n        <div class=\"content\">\n            <div class=\"container\">\n                <h1>Welcome to Cyberball</h1>\n                <!-- Replace '#' in href with the actual path to your pages -->\n                <a click.delegate=\"startFromScratch()\" class=\"btn\">Start From Scratch</a>\n                <a click.delegate=\"loadPreset()\" class=\"btn\">Load Preset</a>\n                <a href=\"#\" class=\"btn\">Manual</a>\n            </div>\n        </div>\n        </body>\n    </div>\n</template>\n";});;
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define('pages/PresetPage/PresetPage',["require", "exports", "aurelia-framework", "aurelia-router", "../Setting-Service"], function (require, exports, aurelia_framework_1, aurelia_router_1, Setting_Service_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PresetPage = void 0;
    let PresetPage = class PresetPage {
        constructor(router, settingsService) {
            this.router = router;
            this.settingsService = settingsService;
            this.presets = [];
            this.defaultPresets = [];
            this.activeTab = 'presets';
        }
        get isLoadFromFile() {
            return this.activeTab === 'load-file';
        }
        attached() {
            this.loadDefaultPresets();
            this.loadPresetsFromLocalStorage();
        }
        loadDefaultPresets() {
            return __awaiter(this, void 0, void 0, function* () {
                try {
                    let response = yield fetch('../../../assets/defaultPresets.json');
                    this.defaultPresets = yield response.json();
                    console.log('loaded default presets', this.defaultPresets);
                }
                catch (error) {
                    console.error('promise rejected', error);
                }
            });
        }
        loadPresetsFromLocalStorage() {
            console.log("Number of items in localStorage:", localStorage.length);
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                const value = localStorage.getItem(key);
                if (value) {
                    const presetData = JSON.parse(value);
                    this.presets.push({
                        name: key,
                        description: presetData.description || 'No description provided',
                        settings: presetData.settings
                    });
                }
            }
            console.log("Presets array:", this.presets);
        }
        loadPresetAndNavigate(preset) {
            this.settingsService.settings = preset.settings;
            this.navigateToConfigurationBuilder();
        }
        showTab(tabId) {
            console.log("Is Your Presets Active?", this.isYourPresetsActive);
            this.activeTab = tabId;
        }
        get isPresetsActive() {
            return this.activeTab === 'presets';
        }
        get isYourPresetsActive() {
            return this.activeTab === 'your-presets';
        }
        get() {
            return this.activeTab === 'load-file';
        }
        deletePreset(presetName) {
            localStorage.removeItem(presetName);
            this.presets = this.presets.filter(p => p.name !== presetName);
        }
        handleFileUpload(event) {
            const file = event.target.files[0];
            if (!file) {
                console.error("No file chosen");
                return;
            }
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                try {
                    const parsedData = JSON.parse(loadEvent.target.result);
                    if (parsedData && parsedData.player && parsedData.player.tint === undefined) {
                        parsedData.player.tint = "#FFFFFF";
                    }
                    if (parsedData) {
                        this.settingsService.settings = parsedData;
                        this.navigateToConfigurationBuilder();
                    }
                    else {
                        console.error("Invalid file format");
                    }
                }
                catch (error) {
                    console.error("Error parsing the file", error);
                }
            };
            reader.readAsText(file);
        }
        navigateToConfigurationBuilder() {
            this.router.navigate('home');
        }
    };
    PresetPage = __decorate([
        (0, aurelia_framework_1.autoinject)(),
        __metadata("design:paramtypes", [aurelia_router_1.Router, Setting_Service_1.SettingsService])
    ], PresetPage);
    exports.PresetPage = PresetPage;
});
;
define('text!pages/PresetPage/PresetPage.css',[],function(){return "\nh1 {\n    text-align: center;\n}\n\nbody {\n    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n    background-color: #f7f7f7;\n    color: #181818;\n    margin: 0;\n    padding: 0;\n}\n\n/* Style for table rows on hover */\n.container table tr:hover {\n    background-color: #f5f5f5; /* Change this to any color you prefer */\n    cursor: pointer;\n}\n\n\n\n.container {\n    text-align: center;\n    background-color: #ffffff;\n    padding: 50px;\n    border-radius: 10px;\n    box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.1);\n    position: relative;\n    width: max-content;\n}\n\ntable {\n    width: 100%;\n    border-collapse: collapse;\n    margin-top: 20px;\n}\n\nth, td {\n    padding: 10px;\n    border-bottom: 1px solid #f1f1f1;\n}\n\nth {\n    background-color: #f7f7f7;\n    color: #333;\n}\n\n/* Tab Styles */\n.tabs {\n    display: flex;\n    border-bottom: 1px solid #e0e0e0; /* Optional: Adds a line under the tabs */\n    overflow: hidden; /* Ensures the content inside the tabs doesn't overflow */\n}\n\n.tab-button {\n    flex: 1; /* Makes each tab button take equal width */\n    padding: 10px 20px;\n    margin: 0;\n    cursor: pointer;\n    background-color: #f7f7f7;\n    border: none;\n    transition: background-color 0.3s ease;\n    border-bottom: 2px solid transparent; /* Optional: Adds a bottom border to indicate active tab */\n}\n\n.tab-button:hover {\n    background-color: #e0e0e0;\n}\n\n.tab-button.active {\n    background-color: #007BFF;\n    color: #ffffff;\n    border-bottom: 2px solid #0056b3; /* Optional: Changes the bottom border color for active tab */\n}\n\n/* This style will target the <tr> elements within your table */\ntable tr:hover th {\n    background-color: #e0e0e0;\n    cursor: pointer;\n}\n\n\n.delete-btn {\n    background-color: grey;\n    color: white;\n    border: none;\n    border-radius: 50%; /* Makes the button circular */\n    width: 20px;\n    height: 20px;\n    font-size: 14px;\n    line-height: 20px;\n    text-align: center;\n    cursor: pointer;\n}\n\n.delete-btn:hover {\n    background-color: darkgrey;\n}\n\n#home-button {\n    background-color: #007BFF;\n    color: #FFFFFF;\n    padding: 10px 20px;\n    margin: 10px;\n    border: none;\n    border-radius: 5px;\n    font-size: 16px;\n    cursor: pointer;\n    transition: background-color 0.3s ease;\n    text-decoration: none;\n}\n#home-button:hover {\n    background-color: #0056b3;\n}\n\n#home-button-container {\n    margin: auto;\n    position: relative;\n    max-width: fit-content;\n    margin-bottom: 40px;\n}\n\ndiv.preset-container {\n    margin: 0 auto;\n    display: block;\n}\n";});;
define('text!pages/PresetPage/PresetPage.html',[],function(){return "<template>\n    <require from=\"resources/value-converters/json-value-converter\"></require>\n    <require from=\"resources/value-converters/integer-value-converter\"></require>\n    <require from=\"resources/value-converters/number-value-converter\"></require>\n    <require from=\"resources/value-converters/integer-array-value-converter\"></require>\n    <require from=\"resources/value-converters/flag-value-converter\"></require>\n    <require from=\"./PresetPage.css\"></require>\n    <require from=\"../LandingPage/LandingPage.css\"></require>\n\n\n        <div class=\"landing-page\">\n            <img src=\"../../../assets/player.png\" alt=\"Cyberball Sprite\" class=\"welcome-image\">\n            <h1>Cyberball Presets</h1>\n            <div id=\"home-button-container\"><a id=\"home-button\" href=\"./\">Return to Landing Page</a></div>\n            <div class=\"tabs\">\n\n                <button class=\"tab-button ${isPresetsActive ? 'active' : ''}\" click.delegate=\"showTab('presets')\">Presets</button>\n                <button class=\"tab-button ${isYourPresetsActive ? 'active' : ''}\" click.delegate=\"showTab('your-presets')\">Your Games</button>\n                <button class=\"tab-button ${isLoadFromFile ? 'active' : ''}\" click.delegate=\"showTab('load-file')\">Load File</button>\n            </div>\n            <div class=\"container preset-container\" id=\"presets\" css.bind=\"isPresetsActive ? 'display: block;' : 'display: none;'\">\n            <table>\n                    <tr>\n                        <th>Name</th>\n                        <th>Description</th>\n                        <th>Video</th>\n                    </tr>\n                    <tr repeat.for=\"defaultPreset of defaultPresets\" click.trigger=\"loadPresetAndNavigate(defaultPreset)\">\n\n                        <td>${defaultPreset.name}</td>\n                        <td>${defaultPreset.description}</td>\n                        <td>\n                            <video width=\"320\" height=\"240\" loop autoplay muted>\n                                <source src=\"${defaultPreset.video}\" type=\"video/mp4\">\n                                Your browser does not support the video tag.\n                            </video>\n                        </td>\n\n                    </tr>\n\n                </table>\n            </div>\n            <div class=\"container preset-container\" id=\"your-presets\" css.bind=\"isYourPresetsActive ? 'display: block;' : 'display: none;'\">\n                <table>\n                    <tr>\n                        <th>Name</th>\n                        <th>Description</th>\n                        <th></th>\n                    </tr>\n\n                    <tr repeat.for=\"preset of presets\" click.trigger=\"loadPresetAndNavigate(preset)\">\n                        <td>${preset.name}</td>\n                        <td>${preset.description}</td>\n                        <td>\n                            <button class=\"delete-btn\" click.trigger=\"deletePreset(preset.name)\">X</button>\n                        </td>\n                    </tr>\n                </table>\n            </div>\n\n            <div class=\"container preset-container\" id=\"load-file\" css.bind=\"isLoadFromFile ? 'display: block;' : 'display: none;'\">\n                <div>\n                    <input type=\"file\" id=\"fileUpload\" change.delegate=\"handleFileUpload($event)\">\n                </div>\n            </div>\n        </div>\n</template>\n\n\n\n";});;
define('pages/Setting-Service',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SettingsService = void 0;
    class SettingsService {
    }
    exports.SettingsService = SettingsService;
});
;
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define('pages/message-test',["require", "exports", "aurelia-templating-resources", "aurelia-framework"], function (require, exports, aurelia_templating_resources_1, aurelia_framework_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MessageTestViewModel = void 0;
    let MessageTestViewModel = class MessageTestViewModel {
        constructor(signaler) {
            this.signaler = signaler;
            this.messages = [];
        }
        bind() {
            window.addEventListener('message', (e) => {
                console.log('message', e.data);
                this.messages.push(e.data);
                this.signaler.signal('message');
            });
        }
    };
    MessageTestViewModel = __decorate([
        (0, aurelia_framework_1.autoinject)(),
        __metadata("design:paramtypes", [aurelia_templating_resources_1.BindingSignaler])
    ], MessageTestViewModel);
    exports.MessageTestViewModel = MessageTestViewModel;
});
;
define('text!pages/message-test.html',[],function(){return "<template>\n    <require from=\"resources/value-converters/json-value-converter\"></require>\n\n    <iframe src=\"/#game\" width=\"800\" height=\"600\"></iframe>\n    <div style=\"border: 1px solid black; width: 800px; height: 200px; overflow-y: auto;\">\n        <div repeat.for=\"message of messages\">${message | json & signal: 'message'}</div>\n    </div>\n</template>\n";});;
define('resources/index',["require", "exports", "aurelia-framework"], function (require, exports, aurelia_framework_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.configure = void 0;
    function configure(config) {
        config.globalResources(aurelia_framework_1.PLATFORM.moduleName('./phaser-game/phaser-game'));
    }
    exports.configure = configure;
});
;
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('resources/phaser-game/phaser-game',["require", "exports", "aurelia-framework", "phaser"], function (require, exports, aurelia_framework_1, phaser_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.PhaserGameCustomElement = void 0;
    phaser_1 = __importDefault(phaser_1);
    let PhaserGameCustomElement = class PhaserGameCustomElement {
        constructor(element) {
            this.element = element;
        }
        bind() {
            this.config.parent = this.element;
            this.game = new phaser_1.default.Game(this.config);
        }
        attached() {
            this.game.scale.updateScale();
        }
    };
    __decorate([
        aurelia_framework_1.bindable,
        __metadata("design:type", Object)
    ], PhaserGameCustomElement.prototype, "config", void 0);
    __decorate([
        aurelia_framework_1.bindable,
        __metadata("design:type", phaser_1.default.Game)
    ], PhaserGameCustomElement.prototype, "game", void 0);
    PhaserGameCustomElement = __decorate([
        (0, aurelia_framework_1.customElement)('phaser-game'),
        (0, aurelia_framework_1.autoinject)(),
        (0, aurelia_framework_1.inlineView)('<template></template>'),
        __metadata("design:paramtypes", [Element])
    ], PhaserGameCustomElement);
    exports.PhaserGameCustomElement = PhaserGameCustomElement;
});
;
define('resources/value-converters/flag-value-converter',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.FlagValueConverter = void 0;
    class FlagValueConverter {
        fromView(value, source, flag) {
            return value ? source | flag : source & ~flag;
        }
        toView(_value, source, flag) {
            return (source & flag) === flag;
        }
    }
    exports.FlagValueConverter = FlagValueConverter;
});
;
define('resources/value-converters/integer-array-value-converter',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.IntegerArrayValueConverter = void 0;
    class IntegerArrayValueConverter {
        fromView(value) {
            value = value.replace(/[^0-9,]/g, '');
            if (value[value.length - 1] == ',')
                value = value.substr(0, value.length - 1);
            return JSON.parse(`[${value}]`);
        }
        toView(value) {
            return JSON.stringify(value).substr(1, value.length * 2 - 1);
        }
    }
    exports.IntegerArrayValueConverter = IntegerArrayValueConverter;
});
;
define('resources/value-converters/integer-value-converter',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.IntegerValueConverter = void 0;
    class IntegerValueConverter {
        fromView(value) {
            value = value || 0;
            return parseInt(value);
        }
    }
    exports.IntegerValueConverter = IntegerValueConverter;
});
;
define('resources/value-converters/json-value-converter',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.JsonValueConverter = void 0;
    class JsonValueConverter {
        toView(value) {
            return JSON.stringify(value, null, 2);
        }
    }
    exports.JsonValueConverter = JsonValueConverter;
});
;
define('resources/value-converters/number-value-converter',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NumberValueConverter = void 0;
    class NumberValueConverter {
        fromView(value) {
            return parseFloat(value !== null && value !== void 0 ? value : '0');
        }
    }
    exports.NumberValueConverter = NumberValueConverter;
});
;
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define('scenes/cyberball',["require", "exports", "phaser", "../game/CyberballGameModel"], function (require, exports, phaser_1, CyberballGameModel_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CyberballScene = void 0;
    phaser_1 = __importDefault(phaser_1);
    CyberballGameModel_1 = __importDefault(CyberballGameModel_1);
    const textStyle = { fontFamily: 'Arial', color: '#000000' };
    class CyberballScene extends phaser_1.default.Scene {
        constructor(settings, controller) {
            super({});
            this.sprites = new Map();
            this.settings = settings;
            this.cyberballGameController = controller;
            this.cyberballGameController.catchBallCallbacks.addCallback("Phaser catch", id => {
                this.catchBall(id);
            });
            this.cyberballGameController.throwBallCallbacks.addCallback("Phaser throw", (thrower, reciever) => {
                this.throwBall(this.sprites.get(thrower), this.sprites.get(reciever));
            });
            this.cyberballGameController.CPULeaveCallbacks.addCallback("Phaser cpu leave", id => {
                this.leaveGame(this.sprites.get(id));
            });
            this.cyberballGameController.gameEndCallbacks.addCallback("Phaser game end", () => {
                this.gameOver();
            });
            this.cyberballGameController.humanPlayerMayLeaveCallbacks.addCallback("Phaser player may leave", () => {
                this.showLeaveButton();
            });
        }
        showLeaveButton() {
            this.leaveButton = this.add.dom(600, 400, 'button', 'width: 100px; height: 50px', 'Leave');
            this.leaveButton.addListener('click');
            this.leaveButton.on('click', () => {
                this.cyberballGameController.endGame('player-leave');
            });
        }
        preload() {
            this.load.crossOrigin = 'anonymous';
            this.load.image('ball', `${this.settings.baseUrl}/${this.settings.ballSprite}`);
            this.load.multiatlas('player', `${this.settings.baseUrl}/player.json`, 'assets');
            if (this.settings.player.portraitBuff) {
                this.textures.addBase64('playerPortrait', this.settings.player.portraitBuff);
            }
            this.settings.computerPlayers.forEach((cpu, i) => {
                if (cpu.portraitBuff) {
                    this.textures.addBase64('cpuPortrait' + i, cpu.portraitBuff);
                }
            });
        }
        createAnimations() {
            this.anims.create({
                key: 'active',
                frames: this.anims.generateFrameNames('player', { start: 1, end: 1, prefix: 'active/', suffix: '.png' })
            });
            this.anims.create({
                key: 'idle',
                frames: this.anims.generateFrameNames('player', { start: 1, end: 1, prefix: 'idle/', suffix: '.png' })
            });
            this.anims.create({
                key: 'throw',
                frameRate: 12,
                frames: this.anims.generateFrameNames('player', { start: 1, end: 3, prefix: 'throw/', suffix: '.png' })
            });
            this.anims.create({
                key: 'catch',
                frames: this.anims.generateFrameNames('player', { start: 1, end: 1, prefix: 'catch/', suffix: '.png' })
            });
        }
        createHumanPlayer() {
            let playerPosition = this.getPlayerPosition();
            this.playerGroup = this.physics.add.group({ immovable: true, allowGravity: false });
            this.playerSprite = this.playerGroup.create(playerPosition.x, playerPosition.y, 'player', 'active/1.png');
            if (this.settings.player.tint)
                this.playerSprite.setTint(parseInt(this.settings.player.tint.substr(1), 16));
            this.playerSprite.setData('name-object', this.add.text(playerPosition.x, playerPosition.y + this.playerSprite.height / 2 + 10, this.settings.player.name, textStyle).setOrigin(0.5));
            if (this.settings.player.portraitBuff) {
                var portraitPosition = this.getPlayerPortraitPosition(this.playerSprite);
                var image = this.add.image(portraitPosition.x, portraitPosition.y, 'playerPortrait');
                let originalWidth = image.width;
                let originalHeight = image.height;
                let maxPortraitHeight = this.settings.portraitHeight || 100;
                let maxPortraitWidth = 100;
                let scale = Math.min(maxPortraitWidth / originalWidth, maxPortraitHeight / originalHeight);
                image.setScale(scale);
            }
            this.sprites.set(CyberballGameModel_1.default.humanPlayerId, this.playerSprite);
        }
        createCPU(i) {
            let cpuPosition = this.getCPUPosition(i);
            let cpuSprite = this.playerGroup.create(cpuPosition.x, cpuPosition.y, 'player', 'idle/1.png');
            cpuSprite.setData('name-object', this.add.text(cpuPosition.x, cpuPosition.y + cpuSprite.height / 2 + 10, this.settings.computerPlayers[i].name, textStyle).setOrigin(0.5));
            if (this.settings.computerPlayers[i].portraitBuff) {
                var portraitPosition = this.getCPUPortraitPosition(i, cpuSprite);
                var image = this.add.image(portraitPosition.x, portraitPosition.y, 'cpuPortrait' + i);
                let originalWidth = image.width;
                let originalHeight = image.height;
                let maxPortraitHeight = this.settings.portraitHeight || 100;
                let maxPortraitWidth = 100;
                let scale = Math.min(maxPortraitWidth / originalWidth, maxPortraitHeight / originalHeight);
                image.setScale(scale);
            }
            cpuSprite.flipX = cpuPosition.x > this.playerSprite.x;
            if (this.settings.computerPlayers[i].tint)
                cpuSprite.setTint(parseInt(this.settings.computerPlayers[i].tint.substring(1), 16));
            cpuSprite.setInteractive();
            cpuSprite.on('pointerdown', (e) => {
                if (this.cyberballGameController.model.playerHoldingBallId === CyberballGameModel_1.default.humanPlayerId) {
                    this.playerSprite.flipX = this.input.x < this.playerSprite.x;
                    let ballPosition = this.getActiveBallPosition(this.playerSprite);
                    this.ballSprite.x = ballPosition.x;
                    this.ballSprite.y = ballPosition.y;
                    this.cyberballGameController.throwBall(i);
                }
            });
            this.sprites.set(i, cpuSprite);
        }
        createCPUs() {
            for (let i = 0; i < this.settings.computerPlayers.length; i++) {
                this.createCPU(i);
            }
        }
        createBall() {
            let ballPosition = this.getActiveBallPosition(this.playerSprite);
            this.ballSprite = this.physics.add.sprite(ballPosition.x, ballPosition.y, 'ball');
            if (this.settings.ballTint)
                this.ballSprite.setTint(parseInt(this.settings.ballTint.substring(1), 16));
            this.physics.add.overlap(this.ballSprite, this.playerGroup, (_b, receiver) => {
                if (this.cyberballGameController.model.playerHoldingBallId === null && receiver === this.throwTarget) {
                    this.cyberballGameController.completeCatch();
                }
            });
        }
        create() {
            this.cameras.main.setBackgroundColor('#ffffff');
            this.createAnimations();
            this.createHumanPlayer();
            this.createCPUs();
            this.createBall();
            if (this.settings.timeLimit > 0 && this.settings.displayTimeLimit) {
                this.timeLimitText = this.add.text(this.sys.canvas.width - 10, 10, this.getTimeString(), textStyle);
                this.timeLimitText.setOrigin(1, 0);
            }
        }
        updateAnimations() {
            if (this.cyberballGameController.model.playerHoldingBallId === CyberballGameModel_1.default.humanPlayerId) {
                this.playerSprite.play('active');
                this.playerSprite.flipX = this.input.x < this.playerSprite.x;
                let ballPosition = this.getActiveBallPosition(this.playerSprite);
                this.ballSprite.x = ballPosition.x;
                this.ballSprite.y = ballPosition.y;
            }
            else if (this.cyberballGameController.model.playerHoldingBallId === null) {
                this.playerGroup.getChildren().forEach(c => {
                    let sprite = c;
                    if (sprite.frame.name.includes('idle'))
                        sprite.flipX = this.ballSprite.x < sprite.x;
                });
            }
        }
        update() {
            if (this.cyberballGameController.model.gameHasEnded)
                return;
            this.updateAnimations();
            if (this.settings.timeLimit > 0 && this.settings.displayTimeLimit) {
                this.timeLimitText.setText(this.getTimeString());
                console.log(this.getTimeString());
            }
        }
        gameOver() {
            this.playerGroup.children.entries.forEach(child => child.removeAllListeners());
            this.physics.pause();
            this.add.rectangle(this.sys.canvas.width / 2, this.sys.canvas.height / 2, this.sys.canvas.width, this.sys.canvas.height, 0xdddddd, this.settings.gameOverOpacity);
            this.add.text(this.sys.canvas.width / 2, this.sys.canvas.height / 2, this.settings.gameOverText, textStyle).setOrigin(0.5);
            if (this.leaveButton != null)
                this.leaveButton.node.style = "visibility: hidden";
        }
        throwBall(thrower, receiver) {
            this.throwTarget = receiver;
            thrower.flipX = receiver.x < thrower.x;
            thrower.play('throw');
            thrower.playAfterRepeat('idle');
            let ballTargetPosition = this.getCaughtBallPosition(receiver);
            this.physics.moveTo(this.ballSprite, ballTargetPosition.x, ballTargetPosition.y, this.settings.ballSpeed);
        }
        catchBall(receiverId) {
            let receiver = this.sprites.get(receiverId);
            receiver.play('catch');
            let ballPosition = this.getCaughtBallPosition(receiver);
            this.ballSprite.body.reset(ballPosition.x, ballPosition.y);
            const cpuSettings = this.settings.computerPlayers[receiverId];
            if (receiver !== this.playerSprite) {
                setTimeout(() => {
                    if (this.cyberballGameController.model.gameHasEnded) {
                        return;
                    }
                    receiver.play('active');
                    const nextTargetId = this.cyberballGameController.getNextTarget(receiverId);
                    if (nextTargetId !== null) {
                        const nextTarget = this.sprites.get(nextTargetId);
                        receiver.flipX = nextTarget.x < receiver.x;
                    }
                    ballPosition = this.getActiveBallPosition(receiver);
                    this.ballSprite.x = ballPosition.x;
                    this.ballSprite.y = ballPosition.y;
                    setTimeout(() => {
                        if (this.cyberballGameController.model.gameHasEnded) {
                            return;
                        }
                        this.cyberballGameController.cpuThrowBall();
                    }, cpuSettings.throwDelay + (Math.random() * 2 - 1) * cpuSettings.throwDelayVariance);
                }, cpuSettings.catchDelay + (Math.random() * 2 - 1) * cpuSettings.catchDelayVariance);
            }
        }
        leaveGame(cpuPlayer) {
            let nameObject = cpuPlayer.getData('name-object');
            nameObject.setText([nameObject.text, 'has left the game.']);
            cpuPlayer.removeAllListeners();
            cpuPlayer.setVisible(false);
        }
        getCPUPosition(i) {
            let padding = 75;
            let extraPadding = this.settings.hasPortraits ? this.settings.portraitHeight + this.settings.portraitPadding * 2 : 0;
            if (this.settings.computerPlayers.length === 1) {
                return new phaser_1.default.Geom.Point(this.sys.canvas.width / 2, padding + extraPadding);
            }
            return new phaser_1.default.Geom.Point(((this.sys.canvas.width - (padding * 2)) / (this.settings.computerPlayers.length - 1)) * i + padding, i === 0 || i === this.settings.computerPlayers.length - 1
                ? (this.sys.canvas.height / 2)
                : padding + extraPadding);
        }
        getCPUPortraitPosition(i, sprite) {
            let position = this.getCPUPosition(i);
            return new phaser_1.default.Geom.Point(position.x, position.y - this.settings.portraitHeight + this.settings.portraitPadding * 2 - sprite.height / 2);
        }
        getPlayerPosition() {
            let padding = 75;
            if (this.settings.hasPortraits)
                padding += this.settings.portraitHeight + this.settings.portraitPadding * 2;
            return new phaser_1.default.Geom.Point(this.sys.canvas.width / 2, this.sys.canvas.height - padding);
        }
        getPlayerPortraitPosition(sprite) {
            var position = this.getPlayerPosition();
            let maxPortraitHeight = this.settings.portraitHeight || 100;
            let yOffset = maxPortraitHeight / 2 + this.settings.portraitPadding * 3 + sprite.height / 2 + 10;
            return new phaser_1.default.Geom.Point(position.x, position.y + yOffset);
        }
        getCaughtBallPosition(target) {
            return new phaser_1.default.Geom.Point(target.x + (target.flipX ? -50 : 50), target.y - 15);
        }
        getActiveBallPosition(target) {
            return new phaser_1.default.Geom.Point(target.x + (target.flipX ? 40 : -40), target.y - 20);
        }
        getTimeString() {
            let timeRemaining = this.settings.timeLimit - this.cyberballGameController.reportTimeSinceStart();
            let time = new Date(timeRemaining < 0 ? 0 : timeRemaining);
            return `${this.settings.timeLimitText} ${time.getUTCMinutes()}:${time.getUTCSeconds() < 10 ? '0' : ''}${time.getUTCSeconds()}`;
        }
    }
    exports.CyberballScene = CyberballScene;
});
;
define('resources',['resources/index'],function(m){return m;});
//# sourceMappingURL=app-bundle.js.map