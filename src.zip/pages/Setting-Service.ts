

export class SettingsService {
    settings: any;
}
